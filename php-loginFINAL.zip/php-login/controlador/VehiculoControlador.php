<?php
include '../datos/VehiculoDAO.php';

class VehiculoControlador{

  public function getVehiculos(){


    return VehiculoDAO::getVehiculos();
  }

  public function crearVehiculo($marca,$patente,$anio,$color,$motor,$km){

    $vehiculo = new Vehiculo();
    $vehiculo->setMarca($marca);
    $vehiculo->setPatente($patente);
    $vehiculo->setAnio($anio);
    $vehiculo->setColor($color);
    $vehiculo->setMotor($motor);
    $vehiculo->setKm($km);

    return VehiculoDAO::agregarVehiculos($vehiculo);
  }
  public function eliminarVehiculo($id){
    return VehiculoDAO::borrarVehiculo($id);
  }

}
