<?php
require '../datos/ClientesDAO.php';

Class ClientesController{

  public static function getClientes(){
    return ClientesDAO::obtenerClientes();
  }


}


 ?>
