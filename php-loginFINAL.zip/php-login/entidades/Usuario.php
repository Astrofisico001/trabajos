<?php
require_once '../datos/Conexion.php';

class Usuario {
  private $uid;
  private $name;
  private $email;
  private $password;

  public function getUid(){
  		return $this->uid;
  	}

  	public function setUid($uid){
  		$this->uid = $uid;
  	}

  	public function getName(){
  		return $this->name;
  	}

  	public function setName($name){
  		$this->name = $name;
  	}

  	public function getEmail(){
  		return $this->email;
  	}

  	public function setEmail($email){
  		$this->email = $email;
  	}

  	public function getPassword(){
  		return $this->password;
  	}

  	public function setPassword($password){
  		$this->password = $password;
  	}

}
