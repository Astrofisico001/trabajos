<?php

/**
 * funcion para limpiar campos y prevenir futuros problemas en la app
 *@param input $campo  campo de tipo POST
 *@return string 
 */
function validar_campo($campo){
  $campo= trim($campo);
  $campo= stripcslashes($campo);
  $campo= htmlspecialchars($campo);
  return $campo;
}
