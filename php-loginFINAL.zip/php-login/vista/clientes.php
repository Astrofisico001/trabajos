
<?php session_start();
 if (!isset($_SESSION["usuario"])) {
       header("location:index.php");
 }


$clientes = file_get_contents("http://68.183.162.82/api/clientes");
$listaClientes = $clientes;
var_dump($listaClientes);
exit;
// This sends a persistent cookie that lasts a day.
session_start(
//  [  'cookie_lifetime' => 86400,]
);

if (!isset($_SESSION["usuario"])) {
  header("location:index.php");


}

include 'partials/menu.php'
 ?>
 <div class="container">

    <h4 class="display-3">Vista de clientes para <?php echo $_SESSION["usuario"]["nombre"]; ?> </h4><br>
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-body">
          <table class="table ">
            <thead class="thead-light">
              <tr class ="font-wight-bold">
                <td>Nombre Completo</td>
                <td>RUT</td>
                <td>Celular</td>
                <td>Email</td>
                <td>Razón Social</td>

              </tr>
            </thead>
            <tbody>

              <?php foreach ($listaClientes as $cliente) {?>
                <tr>
                  <td><?php echo $cliente["nombres"]; ?></td>
                  <td><?php echo $cliente["rut"]; ?></td>
                  <td><?php echo $cliente["celular"]; ?></td>
                  <td><?php echo $cliente["email"] ;?></td>
                  <td><?php echo $cliente["razon_social"]; ?></td>


                </tr>

      <?php } ?>

        </tbody>
        </table>
        </div>
      </div>
    </div>

 </div> <!-- /container -->
 <script type="text/javascript">

  function eliminar(confirmacion, url){
    if(confirmacion){
      window.location.href = url;
    }
  }

 </script>


 <!-- Bootstrap core JavaScript
 ================================================== -->
 <!-- Placed at the end of the document so the pages load faster -->
 <?php include 'partials/footer.php' ?>
