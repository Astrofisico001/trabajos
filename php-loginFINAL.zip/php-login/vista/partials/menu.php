
    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <div class="masthead clearfix">
            <div class="inner">
        <h3 class="masthead-brand">Postulacion Pablo Trigo</h3>
    
               <nav class="nav nav-masthead">
                <a class="nav-link active" href="index.php">Principal</a>


                <a class="nav-link" href="ingresarVehiculos.php">Ingresar Vehiculos</a>
                <a class="nav-link" href="vistaVehiculo.php">Ver Vehiculos</a>
                <a class="nav-link" href="clientes.php">Ver clientes
                </a>



              </nav>
            </div>

          </div>
