<?php

include "../controlador/VehiculoControlador.php";
include '../helps/helps.php';

session_start();
if (isset($_POST ["txtmarca"]) && isset($_POST ["txtpatente"]) && isset($_POST ["txtanio"]) && isset($_POST ["txtcolor"]) && isset($_POST ["txtmotor"]) && isset($_POST["txtkm"]) ) {


  $marca=  $_POST["txtmarca"];
  $patente=  $_POST["txtpatente"];
  $anio=  $_POST["txtanio"];
  $color=  $_POST["txtcolor"];
  $motor=  $_POST["txtmotor"];
  $km=  $_POST["txtkm"];
  header("location:vistaVehiculo.php");

  VehiculoControlador::crearVehiculo($marca,$patente,$anio,$color,$motor,$km);




}
