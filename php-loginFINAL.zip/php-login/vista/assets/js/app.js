$(document).ready(function(){

  $('#loginForm').bind("submit",function(){
      $.ajax({
        type: $(this).attr("method"),
        url: $(this).attr("action"),
        data: $(this).serialize(),
        beforeSend:function(){
          $("#loginForm button[type=submit]").html("Iniciando sesion...");
          $("#loginForm button[type=submit]").attr("disabled","disabled");
        },

        success:function(response){

          if (response=="{\"estado\":\"true\"}") {
            $("body").overhang({
              type: "success",
              message: "Inicio de sesion correcto, redirigiendo...",
              callback:function(){
                window.location.href ="welcome.php"
              }
            });
          }
          else {
            $("body").overhang({
              type: "error",
              message: "ERROR EN INICIO DE SESION, INTENTE NUEVAMENTE"
            });
          }
$("#loginForm button[type=submit]").html("Ingresar");
$("#loginForm button[type=submit]").removeAttr("disabled");
        },error:function() {


        }
      });
      return false;
    });


















  /*  $.ajax({
      type:$(this).attr("method"),
      url:$(this).attr("action"),
      data:$(this).serialize(),
      success:function(response){
        console.log(response);
        if (response.estado ==true) {
          $("body").overhang({
            type:"success", message: "inicio correcto de sesion"
          });
        }else {
          $("body").overhang({
            type:"error", message:"email o password incorrecto"
          });
        }
      },
      //error: function(){
        //$("body").overhang({
        //  type:error, message:"email o password incorrecto"
      //  });
      //}
    });
    return false;*/

});
