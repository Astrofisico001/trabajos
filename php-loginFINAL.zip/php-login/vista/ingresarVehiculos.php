<?php include 'partials/header.php' ?>
<?php session_start();
 if (!isset($_SESSION["usuario"])) {
       header("location:index.php");
 }
            ?>
           <?php include 'partials/menu.php' ?>


          <br><br><br><br><br><br><br>
          <div class="modal-body">
              <form id="frminsert" action="crearVehiculoLogic.php" method="POST" role="form">
                  <label>Marca</label>
                  <input type="text" id="marca" name="txtmarca" class="form-control form-control-sm" required>
                  <label>Patente</label>
                  <input type="text" id="patente" name="txtpatente" class="form-control form-control-sm" required pattern=".{8,8}" title="el largo no debe ser mayor o menor que 8 caracteres">
                  <label>Año</label>
                  <input type="text" id="anio" name="txtanio" class="form-control form-control-sm" required>
                  <label>Color</label>
                  <input type="text" id="color" name="txtcolor" class="form-control form-control-sm" required>
                  <label>Motor</label>
                  <input type="text" id="motor" name="txtmotor" class="form-control form-control-sm"required>
                  <label>Kilometraje</label>
                  <input type="text" id="km" name="txtkm" class="form-control form-control-sm"required>
                  <br>
                   <input type="submit" value="Guardar" class="btn btn-success">
              </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>

<?php include 'partials/footer.php' ?>
