<?php
include '../controlador/UsuarioControlador.php';
session_start();
$resultado = array();

if ($_SERVER["REQUEST_METHOD"]== "POST"){

if (isset($_POST["txtEmail"]) && isset($_POST["txtPassword"])) {


  $txtEmail =$_POST["txtEmail"];
  $txtPassword =$_POST["txtPassword"];
  $resultado = array("estado"=> "true");
  if (UsuarioControlador::login($txtEmail,$txtPassword)) {


  $usuario = UsuarioControlador::getUsuario($txtEmail,$txtPassword);
      $_SESSION ["usuario"]= array(
        "uid"=>$usuario->getUid(),
        "email"=>$usuario->getEmail(),
        "nombre"=>$usuario->getName(),
      );
        return print(json_encode($resultado));
  }

}

}
$resultado = array("estado"=> "false");
return print(json_encode($resultado));
