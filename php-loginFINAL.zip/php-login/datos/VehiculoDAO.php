<?php
require_once 'conexion.php';
include '../entidades/Vehiculo.php';


class VehiculoDAO extends Conexion
{
  protected static $conex;
  public static function getConexion(){
    self::$conex = new conexion();
  }
  private static function desconectar(){
    self::$conex =null;
  }



//METODO PARA LA OBTENCION DEL ARREGLO DE VEHICULOS


  public static function getVehiculos(){
    try {
    $query = "SELECT * FROM vehiculo";
    self::getConexion();
    $resultado = self::$conex->prepare($query);
    $resultado->execute();
    $vehiculos= $resultado->fetchAll();
    return $vehiculos;
    }catch (Exception $ex) {
      echo $ex->getTraceAsString();
    }
  }

//METODO PARA INGRESAR VEHICULOS EN LA BD

public function agregarVehiculos($vehiculo){
  try{
    $query = "INSERT INTO vehiculo (marca,patente,anio,color,motor,km)
              VALUES (?,?,?,?,?,?)";
    self::getConexion();
    $consulta= self::$conex->prepare($query);

    $marca=$vehiculo->getMarca();
    $patente=$vehiculo->getPatente();
    $anio=(int)$vehiculo->getAnio();
    $color=$vehiculo->getColor();
    $motor=$vehiculo->getMotor();
    $km=$vehiculo->getKm();

    $consulta->bindParam(1, $marca);
    $consulta->bindParam(2, $patente);
    $consulta->bindParam(3, $anio);
    $consulta->bindParam(4, $color);
    $consulta->bindParam(5, $motor);
    $consulta->bindParam(6, $km);

    $consulta->execute();
}catch(Exception $ex){
  echo $ex->getTraceAsString();
}
}

//metodo para borrar vehiculos de la bd

public function borrarVehiculo($id){
try {
  $query ="DELETE FROM vehiculo WHERE id=:id";
  self::getConexion();
  $resultado=self::$conex->prepare($query);
  $resultado->bindParam(":id",$id);
  $resultado->execute();
  if ($resultado->execute()) {
    return true;
  }


} catch (Exception $ex) {
  echo $ex->getTraceAsString();
}

}





}
