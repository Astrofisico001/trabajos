<?php
require_once 'conexion.php';
include '../entidades/Usuario.php';

class UsuarioDAO extends Conexion
{
  protected static $conex;
  public static function getConexion(){
  self::$conex =new conexion();
  }
  private static function desconectar(){
    self::$conex = null;
  }

  /**
   * Metodo para validar login
   *@param   object $usuario
   *@return  boolean
   */
   //el usuario se obtiene desde el controlador
  public static function login($usuario){

    try{
    $email = $usuario->getEmail();
    $password = $usuario->getPassword();


    $query = "SELECT
            *
            FROM users
            WHERE email = :email and password = :password";


    self::getConexion();
    $resultado = self::$conex->prepare($query);
    $resultado-> bindParam(":email", $email);
    $resultado-> bindParam(":password", $password);

    $resultado->execute();
    if ($resultado->rowCount()>0) {
      $filas= $resultado->fetch();
      if ($filas["email"]==$usuario->getEmail()
          && $filas["password"]==$usuario->getPassword()) {
            return true;


      }
    }else{
      return false;
    }
  }catch(Exception $ex ){
  echo $ex->getTraceAsString();}
}


    /**
     * METODO PARA OBTENER USUARIO Y USARLO EN LA SESION
      *
      *@param   object $usuario
      *@return  object $usuario
      */
      //el usuario se obtiene desde el controlador
     public static function getUsuario($usuario){

       try{
       $email = $usuario->getEmail();
       $password = $usuario->getPassword();


       $query = "SELECT *
               FROM users
               WHERE email = :email and password = :password";


       self::getConexion();
       $resultado = self::$conex->prepare($query);
       $resultado-> bindParam(":email", $email);
       $resultado-> bindParam(":password", $password);

       $resultado->execute();
       $filas= $resultado->fetch();
       $usuario= new Usuario();
       $usuario->setUid($filas["uid"]);
       $usuario->setEmail($filas["email"]);
       $usuario->setName($filas["name"]);

       return $usuario;

  }catch(Exception $ex ){
  echo $ex->getTraceAsString();
}
  }
}
