<?php

include "../entidades/Cliente.php";



Class ClientesDAO{


public $ruta = "http://68.183.162.82/api/clientes";
public static function obtenerClientes(){
        try {
              $clientes = file_get_contents("http://68.183.162.82/api/clientes");
              var_dump($clientes);
              $listaClientes = json_decode($clientes,true);
              return $listaClientes;
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
