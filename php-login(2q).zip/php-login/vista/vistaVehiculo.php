


           <?php include 'partials/header.php' ?>
           <?php session_start();


           if (!isset($_SESSION["usuario"])) {
             header("location:index.php");


           }
            ?>

<?php include "../controlador/VehiculoControlador.php";
$filas = VehiculoControlador::getVehiculos();
 ?>

           <?php include 'partials/menu.php' ?>

           <div class="container">

              <h4 class="display-3">Vista de vehiculos para <?php echo $_SESSION["usuario"]["nombre"]; ?> </h4><br>
              <div class="col-md-12">
                <br><a href="ingresarVehiculos.php" class="btn btn-primary">Registro de Vehiculos</a><br><br>

              </div>
              <div class="col-md-12">
                <div class="panel panel-default">
                  <div class="panel-body">
                    <table class="table ">
                      <thead class="thead-light">
                        <tr class ="font-wight-bold">
                          <td>Id</td>
                          <td>Marca</td>
                          <td>Patente</td>
                          <td>Año</td>
                          <td>Color</td>
                          <td>Motor</td>
                          <td>Kilometraje</td>
                          <td>Acción</td>

                        </tr>
                      </thead>
                      <tbody>

                        <?php foreach ($filas as $vehiculo) {?>
                          <tr>
                            <td><?php echo $vehiculo["id"] ?></td>
                            <td><?php echo $vehiculo["marca"] ?></td>
                            <td><?php echo $vehiculo["patente"] ?></td>
                            <td><?php echo $vehiculo["anio"] ?></td>
                            <td><?php echo $vehiculo["color"] ?></td>
                            <td><?php echo $vehiculo["motor"] ?></td>
                            <td><?php echo $vehiculo["km"] ?></td>
                            <td>	<a href="javascript:eliminar(confirm('¿Deseas eliminar este registro de vehiculo?'),'eliminarVehiculo.php?id=<?php echo $vehiculo["id"] ?>');" class="btn btn-danger btn-sm">Eliminar</a>
          									</td>
                          </tr>

                <?php } ?>

                  </tbody>
                  </table>
                  </div>
                </div>
              </div>

           </div> <!-- /container -->
           <script type="text/javascript">

           	function eliminar(confirmacion, url){
           		if(confirmacion){
           			window.location.href = url;
           		}
           	}

           </script>


           <!-- Bootstrap core JavaScript
           ================================================== -->
           <!-- Placed at the end of the document so the pages load faster -->
<?php include 'partials/footer.php' ?>
