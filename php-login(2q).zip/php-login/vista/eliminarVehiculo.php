<?php

include '../controlador/VehiculoControlador.php';
include '../helps/helps.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET["id"])) {

        $id = validar_campo($_GET["id"]);

        if (VehiculoControlador::eliminarVehiculo($id)) {
            header("location:vistaVehiculo.php");
        }

    }
} else {
    header("location:index.php?error=1");
}
