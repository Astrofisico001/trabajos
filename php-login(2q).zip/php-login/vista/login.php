<?php include 'partials/header.php' ?>
<?php
session_start();
 if (isset($_SESSION["usuario"])) {
  header("location:welcome.php");


} ?>
<?php include 'partials/menu.php' ?>

          <div class="inner cover">

            <br/><br/><br/><br/><br/><br/>
          <div class="row" align="center">
            <div class="col-md-4 col-md-offset4" align="center">
              <div class="panel-body" align="center">
                <form action="validacion.php" id="loginForm" method="POST" role="form">
                  <legend>Iniciar sesion</legend>

                    <fieldset class="form-group">
                      <label for="email">Email</label>
                      <input type="text" name="txtEmail" id="email" class="form-control" autofocus required  placeholder="Email">
                    </fieldset>
                    <fieldset class="form-group">
                      <label for="password">Contraseña</label>
                      <input type="password" name="txtPassword" id="password" class="form-control" placeholder="Contraseña">
                    </fieldset>
                    <fieldset>
                        <button type="submit" class="btn btn-success" name="button">Iniciar sesión</button>
                    </fieldset>




                </form>
              </div>
              </div>
            </div>
          </div>




          </div>

          <div class="mastfoot">
            <div class="inner">
              <p></a></p>
            </div>
          </div>

        </div>

      </div>

    </div>
<?php include 'partials/footer.php' ?>
