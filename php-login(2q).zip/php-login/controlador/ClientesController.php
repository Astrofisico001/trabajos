<?php
include '../datos/ClientesDAO.php';

Class ClientesController{

  public function getClientes(){
    return ClientesDAO::obtenerClientes();
  }


}


 ?>
