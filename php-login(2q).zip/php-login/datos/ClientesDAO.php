<?php

include "../entidades/Cliente.php";



Class ClientesDAO{


public $ruta = "http://68.183.162.82/api/clientes";
public function obtenerClientes(){
        try {
            $clientes = file_get_contents($this->ruta);
            $listaClientes = json_decode($clientes,true);
            return $listaClientes;
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
