<?php

class Cliente{


  private $nombreCompleto;
  private $rut;
  private $celular;
  private $email;
  private $razonSoc;

  public function getNombreCompleto(){
		return $this->nombreCompleto;
	}

	public function setNombreCompleto($nombreCompleto){
		$this->nombreCompleto = $nombreCompleto;
	}

	public function getRut(){
		return $this->rut;
	}

	public function setRut($rut){
		$this->rut = $rut;
	}

	public function getCelular(){
		return $this->celular;
	}

	public function setCelular($celular){
		$this->celular = $celular;
	}

	public function getEmail(){
		return $this->email;
	}

	public function setEmail($email){
		$this->email = $email;
	}

	public function getRazonSoc(){
		return $this->razonSoc;
	}

	public function setRazonSoc($razonSoc){
		$this->razonSoc = $razonSoc;
	}

}

 ?>
