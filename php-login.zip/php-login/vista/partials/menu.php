    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <div class="masthead clearfix">
            <div class="inner">
        <h3 class="masthead-brand">Postulacion Pablo Trigo</h3>
        <br/>
        <br/>
        <br/>
               <nav class="nav nav-masthead">
                <a class="nav-link active" href="index.php">Principal</a>
                 

                <a class="nav-link" href="clientes">Ingresar Vehiculos</a>
                <a class="nav-link" href="clientes">Ver Vehiculos</a>
                <a class="nav-link" href="clientes">Borrar Vehiculos</a>

                <br/>
                <br/>
                <br/>
                <br/>

              </nav>
            </div>

          </div>
