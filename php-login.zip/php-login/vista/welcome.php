
<?php include 'partials/header.php' ?>
<?php session_start();


if (!isset($_SESSION["usuario"])) {
  header("location:index.php");


}
 ?>
<?php include 'partials/menu.php' ?>

          <div class="inner cover">

            <br/><br/><br/><br/><br/><br/>
            <a href="logout.php"class="btn btn-primary btn-lg"  role="button">Cerrar sesion</a>
            <div class="jumbotron">
              <h1 class="display-3">Bienvenido <?php echo $_SESSION["usuario"]["nombre"]; ?> </h1>
            <!--  <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
              <hr class="m-y-md">
              <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
              <p class="lead">-->

                <a href="clientes.php"class="btn btn-primary btn-lg" href="#" role="button">Ver clientes</a>

              </p>
            </div>




          </div>

          <div class="mastfoot">
            <div class="inner">
              <p>Cover template for <a href="http://getbootstrap.com">Bootstrap</a>, by <a href="https://twitter.com/mdo">@mdo</a>.</p>
            </div>
          </div>

        </div>

      </div>

    </div>
<?php include 'partials/footer.php' ?>
