<?php include 'partials/header.php' ?>
<?php include 'partials/menu.php' ?>

          <div class="inner cover">

            <br/><br/><br/><br/><br/><br/>
            <div class="jumbotron">
              <h1 class="display-3">Prueba pablo trigo </h1>
            <!--  <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
              <hr class="m-y-md">
              <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
              <p class="lead">-->

                <a href="login.php"class="btn btn-primary btn-lg" href="#" role="button">Iniciar sesion</a>
              </p>
            </div>




          </div>

          <div class="mastfoot">
            <div class="inner">
              <p>Cover template for <a href="http://getbootstrap.com">Bootstrap</a>, by <a href="https://twitter.com/mdo">@mdo</a>.</p>
            </div>
          </div>

        </div>

      </div>

    </div>
<?php include 'partials/footer.php' ?>
