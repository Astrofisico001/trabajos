<?php
include '../datos/UsuarioDAO.php';

class UsuarioControlador{

  //se crea una instancia de usuario con el email y password obtenidos en el formulario de login
  //para que la capa de datos pueda acceder a este y consultarlo en la bd
  public function login($email,$password){
    $obj_usuario= new Usuario();
    $obj_usuario->setEmail($email);
    $obj_usuario->setPassword($password);


    return UsuarioDAO::login($obj_usuario);

  }
  public function getUsuario($email,$password){
    $obj_usuario= new Usuario();
    $obj_usuario->setEmail($email);
    $obj_usuario->setPassword($password);

    return UsuarioDAO::getUsuario($obj_usuario);
  }

}
