<?php
require_once 'conexion.php';
include '../entidades/Vehiculo.php';


class VehiculoDAO extends Conexion
{
  protected static $conex;
  public static function getConexion(){
    self::$conex = new conexion();
  }
  privavte static function desconectar(){
    self::$conex =null;
  }

  public static function getVehiculos(){
    $query = "SELECT * FROM vehiculo";
    self::getConexion();
    $resultado = self::$conex->prepare($query);
    $resultado->execute();
    $vehiculos= $resultado->fetchAll();
    return $vehiculos;



  }







}


 ?>
